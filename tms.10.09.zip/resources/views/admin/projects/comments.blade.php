@section('comments')
	@include('comments.comments_block', ['essence' => null])
@endsection
