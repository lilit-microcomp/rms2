@extends('layouts.default')
@section('content')
    i am an admin.
@stop
