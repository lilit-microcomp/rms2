<?php if(count($comments) > 0): ?>
    <ul>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!$comment->parent_id): ?>
                <?php echo $__env->make('comments.comments_block', [
                        'comment' => $comment,
                        'comment_id' =>$comment->id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
