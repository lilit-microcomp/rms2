<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h3>Users list</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
          <div class="text-right">
            <a class="btn btn-xs btn-success" href="<?php echo e(route('users.create')); ?>">Create new user</a>
          </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
      </div>
    <?php endif; ?>

    <table class="table table-dashboard">
      <tr>
        <th>No_</th>
        <th>Id</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
        <th>Role</th>
        <th width="300px"></th>
      </tr>

      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($user->id); ?></td>
          <th><?php echo e($user->firstname); ?></th>
          <th><?php echo e($user->lastname); ?></th>
          <th><?php echo e($user->email); ?></th>
          <th><?php echo e($user->role_name); ?></th>
          <td>
            <!-- <a class="btn btn-xs btn-info" href="<?php echo e(route('users.show', $user->id)); ?>">Show</a> -->
            <a class="btn btn-xs btn-primary" href="<?php echo e(route('users.edit', $user->id)); ?>">Edit</a>
            <?php echo Form::open(['method' => 'DELETE', 'route' => ['users.destroy', $user->id], 'style'=> 'display:inline']); ?>

                <?php echo Form::submit('Delete',['class'=> 'btn btn-xs btn-danger']); ?>

            <?php echo Form::close(); ?>

          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $users->links(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'layouts.appadmin' : 'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>