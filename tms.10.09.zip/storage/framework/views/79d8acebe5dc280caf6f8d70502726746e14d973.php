<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo URL::asset('js/admin/tasks/index.js'); ?>"></script>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h3>Third party access data</h3>
        </div>
    </div>

    <?php if(Auth::user()->role_id == 1): ?>
        <div class="row">
            <div class="col-lg-12">

                <div class="text-right">
                    <a class="btn btn-xs btn-success" href="<?php echo e(route('thirdparty.create')); ?>">Create new access data</a>
                </div>

            </div>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-dashboard">
        <tr>
            <th>Website</th>
            <th>Username</th>
            <th>Password</th>
            <th>Description</th>
            <?php if(Auth::user()->role_id == 1): ?>
                <th>Controls</th>
            <?php endif; ?>

        </tr>

    <?php $__currentLoopData = $accesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td><?php echo e($access->website); ?></td>
                <td><?php echo e($access->username); ?></td>
                <td><?php echo e($access->password); ?></td>
                <td><?php echo e($access->description); ?></td>


                <?php if(Auth::user()->role_id == 1): ?>
                    <td>
                    <?php echo Form::open(['method' => 'GET', 'route' => ['thirdparty.edit', $access->id], 'style'=> 'display:inline']); ?>

                        <?php echo Form::submit('Edit',['class'=> 'btn btn-xs btn-primary']); ?>

                    <?php echo Form::close(); ?>


                        <!--<a class="btn btn-xs btn-primary" href="">Show</a>-->
                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['thirdparty.destroy', $access->id], 'style'=> 'display:inline']); ?>

                            <?php echo Form::submit('Delete',['class'=> 'btn btn-xs btn-danger']); ?>


                        <?php echo Form::close(); ?>




                    </td>
                <?php endif; ?>
            </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make( Auth::user()->role_id == 1? 'layouts.appadmin' :  'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>