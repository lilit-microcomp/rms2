<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h3>Projects list</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="text-left">
                <a class="btn btn-xs btn-primary" href="<?php echo route('projects.index', 0); ?>">All</a>
                <a class="btn btn-xs btn-primary" href="<?php echo route('projects.index', 1); ?>">Open</a>
                <a class="btn btn-xs btn-primary" href="<?php echo route('projects.index', 2); ?>">Closed</a>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-right">
                <a class="btn btn-xs btn-success" href="<?php echo e(route('projects.create')); ?>">Create new project</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
      </div>
    <?php endif; ?>

    <table class="table table-dashboard">
      <tr>
        <th>Client</th>
        <th>Due date</th>
        <th>Status</th>
        <th>Project description</th>
        <th>Manager</th>
        <th>Controls</th>
      </tr>

      <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
              <?php if($project->proj_projstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e($project->companyname); ?></span><br>
              <?php else: ?>
                  <?php echo e($project->companyname); ?><br>
              <?php endif; ?>

              <?php if($project->proj_projstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e($project->email); ?></span><br>
              <?php else: ?>
                  <?php echo e($project->email); ?><br>
              <?php endif; ?>
              <?php if($project->proj_projstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e($project->phonenumber); ?></span><br>
              <?php else: ?>
                  <?php echo e($project->phonenumber); ?><br>
              <?php endif; ?>
          </td>
          <th>
              <?php if($project->proj_projstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e($project->due_date); ?></span>
              <?php else: ?>
                  <?php echo e($project->due_date); ?>

              <?php endif; ?>
          </th>
          <th>
              <?php if($project->proj_projstatus == 1): ?>
                  <?php if($project->status == 0): ?>
                      <span style="color: #CCCCCC">Open</span>
                  <?php elseif($project->status == 1): ?>
                        <span style="color: #CCCCCC">Closed</span>
                  <?php endif; ?>
              <?php else: ?>
                  <?php if($project->status == 0): ?>
                        <span>Open</span>
                  <?php elseif($project->status == 1): ?>
                        <span>Closed</span>
                  <?php endif; ?>
              <?php endif; ?>
          </th>
          <th>
              <?php if($project->proj_projstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e($project->descriptive_title); ?></span><br>
              <?php else: ?>
                  <?php echo e($project->descriptive_title); ?><br>
              <?php endif; ?>
              <?php if($project->proj_projstatus == 1): ?>
                      <span style="color: #CCCCCC"><a href="<?php echo e($project->project_url); ?>"><?php echo e($project->project_url); ?></a></span>
              <?php else: ?>
                  <a href="<?php echo e($project->project_url); ?>"><?php echo e($project->project_url); ?></a>
              <?php endif; ?>
          </th>
          <th>
              <?php if($project->proj_projstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e($project->firstname); ?></span>
              <?php else: ?>
              <?php echo e($project->firstname); ?>


              <?php endif; ?>
          </th>
          <td>
              <a href="/projects/<?php echo e($project->proj_projid); ?>/finish-proj">
                  <?php if($project->proj_projstatus == 0): ?>
                      <i class="fa fa-times-circle" style="color: #007bff; margin-left: 20px;"></i>
                  <?php else: ?>
                      <i class="fa fa-check-circle" style="color: #007bff; margin-left: 20px;"></i>

                  <?php endif; ?>
              </a>

              <!--<?php echo Form::open(['method' => 'GET', 'route' => ['projects.edit', $project->project_id], 'style'=> 'display:inline']); ?>

              <?php echo Form::submit('Edit',['class'=> 'btn btn-xs btn-primary']); ?>

              <?php echo Form::close(); ?>-->

              <?php if($project->proj_projstatus == 0): ?>
                  <a class="btn btn-xs btn-primary" href="<?php echo e(route('support.edit', $project->project_id)); ?>"><i class="fa fa-edit"></i></a>
              <?php endif; ?>



            <?php echo Form::open(['method' => 'DELETE', 'route' => ['projects.destroy', $project->id], 'style'=> 'display:inline']); ?>

                <!--<?php echo Form::submit('Delete',['class'=> 'btn btn-xs btn-danger']); ?>-->
              <input type="submit" value="&#xf1f8" class="fa fa-trash" style="color: red; font-size: 18px; margin-bottom: 0;">
            <?php echo Form::close(); ?>

          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $projects->links(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'layouts.appadmin' : 'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>