<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>


<h4>{{name}},</h4>

<h4>A new project has been created for you at MicroComp's Task Management System. The deadline of this project is {{deadline}}. Below is the project description:</h4>

<h4>description</h4>

--
<h4>MicroComp LLC</h4>
<h4>850 Colorado Blvd., Suite 104</h4>
<h4>Los Angeles, CA 90041</h4>
<h4>http://www.micro-comp.com/</h4>
<h4>hayk@micro-comp.com</h4>
<h4>Tel.: 1 (818) 794-9109</h4>


----
<h4>Disclaimer - This message may contain information that is not intended for you. If you are not the addressee or if this message was sent to you by mistake, you are requested to inform the sender and delete the message.</h4>


</body>
</html>