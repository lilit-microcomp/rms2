<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>

<h4>Dear {{$firstname}},</h4><br>
<h4>An account has been registered for you at MicroComp LLC's Task Management System.</h4><br>
<h4>Your email address is your username and below is your password:
    {{$password}}</h4><br><br>
<h4>Please follow this link to login http://www.micro-comp.com/jobs/</h4>

</body>

</html>