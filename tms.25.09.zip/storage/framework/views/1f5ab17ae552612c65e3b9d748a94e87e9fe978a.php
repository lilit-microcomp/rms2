<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo URL::asset('js/admin/tasks/index.js'); ?>"></script>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
            <h3>Tasks list</h3>
        </div>
    </div>
    <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2 || Auth::user()->role_id == 4): ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-inline text-left">
                <div class="form-group col-md-6">
                    <label for="user_id" class="bold col-md-4 col-form-label text-md-right">Choose developer: </label>
                    <?php echo e(Form::select('user_id', $users, null, ['placeholder' => 'Please select ...', 'class' => 'form-control'])); ?>

                </div>
            </div>

            <div class="text-right">
                <a class="btn btn-xs btn-success" href="<?php echo e(route('tasks.create')); ?>">Create new task</a>
            </div>

        </div>
    </div>
    <?php endif; ?>

    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
      </div>
    <?php endif; ?>

    <table class="table table-dashboard">
      <tr>
        <th>Company name</th>
        <th>Project</th>
        <th>Due date</th>
        <th>Manager</th>
        <th>Team lead</th>
        <th>Developer(s)</th>
        <th>Controls</th>
      </tr>

      <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
          <td>
              <?php if($task->task_taskstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e($task->companyname); ?></span>
              <?php else: ?>
                  <?php echo e($task->companyname); ?>

              <?php endif; ?>
          </td>
          <td>
              <?php if($task->task_taskstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo $task->description; ?></span>
              <?php else: ?>
                  <?php echo $task->description; ?>

              <?php endif; ?>
          </td>
          <th>
              <?php if($task->task_taskstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e($task->due_date); ?></span>
              <?php else: ?>
                  <?php echo e($task->due_date); ?>

              <?php endif; ?>
          </th>
          <th>
              <?php $__currentLoopData = $users_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($user_project->project_id == $task->project_id): ?>
                      <?php if($task->task_taskstatus == 1): ?>
                          <span style="color: #CCCCCC"><?php echo e($user_project->firstname); ?></span>
                      <?php else: ?>
                          y<?php echo e($user_project->firstname); ?>

                      <?php endif; ?>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </th>
          <th>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($key == $task->team_lead_id): ?>
                      <?php if($task->task_taskstatus == 1): ?>
                          <span style="color: #CCCCCC"><?php echo e($value); ?></span>
                      <?php else: ?>
                          <?php echo e($value); ?>

                      <?php endif; ?>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </th>
          <th>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($key == $task->developer_id): ?>
                      <?php if($task->task_taskstatus == 1): ?>
                          <span style="color: #CCCCCC"><?php echo e($value); ?></span>
                      <?php else: ?>
                          <?php echo e($value); ?>

                      <?php endif; ?>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </th>

          <td>
              <a href="/tasks/<?php echo e($task->task_taskid); ?>/finish-task">
                  <?php if($task->task_taskstatus == 0): ?>
                      <i class="fa fa-times-circle" style="color: #007bff; margin-left: 20px;"></i>
                  <?php else: ?>
                      <i class="fa fa-check-circle" style="color: #007bff; margin-left: 20px;"></i>

                  <?php endif; ?>
              </a>


              <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2 || Auth::user()->role_id == 4 && $task->status == 'Closed'): ?>
                <?php if($task->task_taskstatus == 0): ?>
                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('tasks.edit', $task->task_taskid)); ?>"><i class="fa fa-edit"></i></a>
                <?php endif; ?>
              <?php endif; ?>
            <a class="btn btn-xs btn-primary" href="<?php echo e(route('tasks.show', $task->task_taskid)); ?>"><i class="fa fa-eye"></i></a>


                <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2 || Auth::user()->role_id == 4): ?>
                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['tasks.destroy', $task->task_id], 'style'=> 'display:inline']); ?>


                    <!--<?php echo Form::submit('Delete',['class'=> 'btn btn-xs btn-danger']); ?>-->
                        <input type="submit" value="&#xf1f8" class="fa fa-trash" style="color: red; font-size: 18px; margin-bottom: 0;">
                    <?php echo Form::close(); ?>

                <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $tasks ->links(); ?>





<?php $__env->stopSection(); ?>

<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'layouts.appadmin' : 'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>