<meta charset="utf-8">
<meta name="description" content="MICROCOMP">
<meta name="author" content="MICROCOMP">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo e(config('app.name', 'MICROCOMP')); ?></title>

<link rel="stylesheet" href="<?php echo e(URL::asset('css/app.css')); ?>">

<link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('comments/css')); ?>/comments.css" />

<link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap-theme.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('comments/js')); ?>/comment-reply.js" /></script>
<script type="text/javascript" src="<?php echo e(asset('comments/js')); ?>/comment-scripts.js" /></script>
