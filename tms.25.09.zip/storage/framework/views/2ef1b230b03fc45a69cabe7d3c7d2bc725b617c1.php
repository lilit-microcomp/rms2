    


<?php echo e($tasks); ?>


<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'dashboard.admin' : 'dashboard.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>