<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script type="text/javascript" src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo URL::asset('js/admin/support/index.js'); ?>"></script>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h3>Support list</h3>
        </div>
    </div>
    <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2 || Auth::user()->role_id == 4): ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-inline text-left">
                <div class="form-group col-md-6">
                    <label for="user_id" class="bold col-md-4 col-form-label text-md-right">Choose developer: </label>
                    <?php echo e(Form::select('user_id', $users, null, ['placeholder' => 'Please select ...', 'class' => 'form-control'])); ?>

                </div>
            </div>
            <div class="text-right">
                <a class="btn btn-xs btn-success" href="<?php echo e(route('support.create')); ?>">Create new support</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
      </div>
    <?php endif; ?>

    <table class="table table-dashboard">
      <tr>
        <th>No_</th>
        <th>Project</th>
        <th>due date</th>
        <!--<th>Support url</th>-->
        <th>Manager</th>
        <th>Team lead</th>
        <th>Developer(s)</th>
        <th>Controls</th>
      </tr>

      <?php $__currentLoopData = $support; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
              <?php if($supp->supp_suppstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e(++$i); ?></span>
              <?php else: ?>
                  <?php echo e(++$i); ?>

              <?php endif; ?>
          </td>
          <td>
              <?php if($supp->supp_suppstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo $supp->description; ?></span>
              <?php else: ?>
                  <?php echo $supp->description; ?>

              <?php endif; ?>
          </td>
          <th>
              <?php if($supp->supp_suppstatus == 1): ?>
                  <span style="color: #CCCCCC"><?php echo e($supp->due_date); ?></span>
              <?php else: ?>
                  <?php echo e($supp->due_date); ?>

              <?php endif; ?>
          </th>
        <!--<th>project_url</th>-->
          <th>

              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($key == $supp->pm_id): ?>
                      <?php if($supp->supp_suppstatus == 1): ?>
                          <span style="color: #CCCCCC"><?php echo e($value); ?></span>
                      <?php else: ?>
                          <?php echo e($value); ?>

                      <?php endif; ?>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </th>
          <th>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($key == $supp->team_lead_id): ?>
                      <?php if($supp->supp_suppstatus == 1): ?>
                          <span style="color: #CCCCCC"><?php echo e($value); ?></span>
                      <?php else: ?>
                          <?php echo e($value); ?>

                      <?php endif; ?>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </th>
          <th>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($key == $supp->developer_id): ?>
                      <?php if($supp->supp_suppstatus == 1): ?>
                          <span style="color: #CCCCCC"><?php echo e($value); ?></span>
                      <?php else: ?>
                          <?php echo e($value); ?>

                      <?php endif; ?>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </th>

          <td>
              <a href="/supports/<?php echo e($supp->support_supportid); ?>/finish-supp">
                  <?php if($supp->supp_suppstatus == 0): ?>
                      <i class="fa fa-times-circle" style="color: #007bff; margin-left: 20px;"></i>
                  <?php else: ?>
                      <i class="fa fa-check-circle" style="color: #007bff; margin-left: 20px;"></i>

                  <?php endif; ?>
              </a>

            <!-- <a class="btn btn-xs btn-info" href="<?php echo e(route('support.show', $supp->id)); ?>">Show</a> -->

                <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2 || Auth::user()->role_id == 4): ?>
                  <?php if($supp->supp_suppstatus == 0): ?>
                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('support.edit', $supp->support_id)); ?>"><i class="fa fa-edit"></i></a>
                  <?php endif; ?>
                <?php endif; ?>

                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('support.show', $supp->support_id)); ?>"><i class="fa fa-eye"></i></a>

            <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2 || Auth::user()->role_id == 4): ?>
                <?php echo Form::open(['method' => 'DELETE', 'route' => ['support.destroy', $supp->support_id], 'style'=> 'display:inline']); ?>

                    <!--<?php echo Form::submit('Delete',['class'=> 'btn btn-xs btn-danger']); ?>-->
                  <input type="submit" value="&#xf1f8" class="fa fa-trash" style="color: red; font-size: 18px; margin-bottom: 0;">
                <?php echo Form::close(); ?>

            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $support->links(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'layouts.appadmin' : 'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>