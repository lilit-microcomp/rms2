<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
<style>


    /*open and close task's details*/
    .taskNotesDetails {
        width: 100%;
        padding: 50px 0;
        text-align: center;
        background-color: lightblue;

    }

/*

    //Style the buttons
    .taskNotesBtn {
        border: none;
        outline: none;
        padding: 10px 16px;
        background-color: #f1f1f1;
        cursor: pointer;
        font-size: 18px;
    }

    //Style the active class, and buttons on mouse-over
    .active, .taskNotesBtn:hover {
        background-color: #666;
        color: white;
    }
    */


    /* open popup of access data */
    .clicker {
        /*width:100px;
        height:100px;
        background-color:blue;*/
        outline:none;
        cursor:pointer;
    }

    .hiddendiv{
        display:none;
        /*height:200px;
        background-color:green;*/
    }

    .clicker:focus + .hiddendiv{
        display:block;
        position: fixed; /* Stay in place */
        z-index: 1; /* Sit on top */
        padding-top: 100px; /* Location of the box */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
        background-color: rgb(0,0,0); /* Fallback color */
        background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    }
    .sub{
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 50%;
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="float: left;">
        NOW NOTES: <b>Tasks</b>
        <div id="tasksNote" style="min-height: 360px;">
        <?php $__currentLoopData = $task_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="background-color: #efefef; margin-top: 20px; padding:10px;">
            <div style="float: left; color: #007bff;"><?php echo e($task_comment->project_url); ?> <i class="fa fa-angle-down"></i></div>
            <div style="float: right;">
                <?php echo e($task_comment->comment_created_at); ?>

                <?php echo e($task_comment->comment_id); ?>

                <a href="/home/<?php echo e($task_comment->comment_id); ?>/finish-note">

                    <?php if($task_comment->comment_status == 0): ?>
                        <i class="fa fa-times-circle" style="color: #007bff; margin-left: 20px;"></i>
                    <?php else: ?>
                        <i class="fa fa-check-circle" style="color: #007bff; margin-left: 20px;"></i>

                    <?php endif; ?>
                </a>
            </div>

            <!--<button class="taskNotesBtn">1</button>-->
        </div>
            <!-- class="taskNotesDetails" -->
        <div class="taskNotesDetails" style="background-color: #efefef; padding: 10px; text-align: left;">
            <?php echo $task_comment->text; ?>

        </div>



        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div style="margin-bottom: 20px; margin-top: 20px;">
            <b style="font-size: 18px; margin-right: 30px;">OPEN TASKS</b>
            <?php echo Form::text('name'); ?>

        </div>

        <table style="width: 100%;">
            <tr>
                <td><b>Project</b></td>
                <td><b>Due Date</b></td>
                <td><b>Developer</b></td>
                <td><b>Controls</b></td>
            </tr>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($task->project_name); ?><br></td>
                    <td><?php echo e($task->task_due_date); ?></td>
                    <td><?php echo e($task->firstname); ?></td>
                    <td>

                        <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2 || Auth::user()->role_id == 4): ?>
                            <a href="<?php echo e(route('tasks.edit', $task->id)); ?>">
                                <i class="fa fa-edit" style="font-size: 12px; color: #007bff; float: left; margin-left: 2px;"></i>
                            </a>
                        <?php endif; ?>
                        <div class="clicker" tabindex="1" style="float: left; margin-left: 2px;"><i class="fa fa-upload" style="font-size: 12px; color: #007bff; cursor: pointer;" title="file upload"></i></div>
                        <div class="hiddendiv"><div class="sub">

                                <?php echo Form::open(array('route' => 'fileUpload','enctype' => 'multipart/form-data')); ?>




                                <div class=" cancel"> <!-- row -->
                                    <div class="col-md-4">
                                        <?php echo Form::file('image', array('class' => 'image')); ?>

                                    </div><br>
                                    <div class="col-md-4">
                                        <button type="submit" class="btn btn-success">Upload</button>
                                    </div>
                                </div>
                                <?php echo Form::close(); ?>


                        </div></div>

                         <div class="clicker" tabindex="1" style="float: left; margin-left: 2px;"><i class="fa fa-download" style="font-size: 12px; color: #007bff; cursor: pointer;" title="show access data"></i></div>
                         <div class="hiddendiv"><div class="sub">
                                 <?php
                                 //echo $tasks[1]->files;
                                 $task_files = (explode(",", $task->files));
                                 unset($task_files[0]);
                                 ?>
                                     <?php $__currentLoopData = $task_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <a href="/images/<?php echo $task_file; ?>" download> <p style="color: #007bff"><?php echo $task_file; ?></p> </a>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </div></div>






                        <!-- Trigger/Open The Modal -->

                        <div class="clicker" tabindex="1" style="float: left; margin-left: 2px;"><i class="fa fa-key" style="font-size: 12px; color: #007bff; cursor: pointer;" title="show access data"></i></div>
                        <div class="hiddendiv"><div class="sub"><?php echo $task->access_data; ?></div></div>
                        <a href="/home/<?php echo e($task->task_taskid); ?>/finished">
                        <?php if($task->task_status == 0): ?>
                                <i class="fa fa-close" style="font-size: 12px; color: #007bff; float: left; margin-left: 2px;"></i>
                        <?php else: ?>
                                <i class="fa fa-check" style="font-size: 12px; color: #007bff; float: left; margin-left: 2px;"></i>
                        <?php endif; ?>
                        </a>







                    </td>
                </tr>





            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>



    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style="float: left;">
        NOW NOTES: <b>Support</b>
        <div id="supportNote" style="min-height: 360px;">
            <?php $__currentLoopData = $support_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $support_comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="background-color: #efefef; margin-top: 20px; padding:10px;"><div style="float: left; color: #007bff;"><?php echo e($task_comment->project_url); ?> <i class="fa fa-angle-down"></i></div>
                    <div style="float: right;">
                        <?php echo e($support_comment->comment_created_at); ?>

                        <?php echo e($support_comment->id); ?>

                        <!--<a href="/home/<?php echo e($support_comment->id); ?>/finish-note">-->
                        <a href='/home/<?php echo e($support_comment->comments_id); ?>/finish-supp-note'>
                            <?php if($support_comment->comment_status == 0): ?>
                                <i class="fa fa-times-circle" style="color: #007bff; margin-left: 20px;"></i>
                            <?php else: ?>
                                <i class="fa fa-check-circle" style="color: #007bff; margin-left: 20px;"></i>

                            <?php endif; ?>
                        </a>
                        <!--</a>-->
                    </div>

                    <!--<button class="taskNotesBtn">1</button>-->
                </div>
                <!-- class="taskNotesDetails" -->
                <div class="supportNotesDetails" style="background-color: #efefef; padding: 10px; text-align: left;">
                    <?php echo $support_comment->text; ?>

                </div>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!--<div style="background-color: #efefef; height: 75px; margin-top: 20px;"></div>
        <div style="background-color: #efefef; height: 75px; margin-top: 20px;"></div>
        <div style="background-color: #efefef; height: 75px; margin-top: 20px;"></div>
        <div style="background-color: #efefef; height: 75px; margin-top: 20px;"></div>-->


        <div style="margin-bottom: 20px; margin-top: 20px;">
            <b style="font-size: 18px; margin-right: 30px;">SUPPORT</b>
            <?php echo Form::text('name'); ?>

        </div>

        <table style="width: 100%;">
            <tr>
                <td><b>URL</b></td>
                <td><b>Developer</b></td>
                <td><b>To Do</b></td>
                <td><b>Controls</b></td>
            </tr>
            <?php $__currentLoopData = $supports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $support): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($support->project_url); ?><br></td>
                    <td><?php echo e($support->support_due_date); ?></td>
                    <td>
                        <i class="fa fa-wrench" style="font-size: 12px; color: #cb1616"></i>
                        <i class="far fa-hdd" style="font-size: 12px; color: #cb1616"></i>
                    </td>
                    <td>
                        <?php echo e($done_notes); ?>

                        <?php if($done_notes == 'false'): ?>
                            <i class="fa fa-exclamation" style="font-size: 12px; color: #cb1616; float: left; margin-left: 2px;"></i>
                        <?php endif; ?>
                        <?php echo e($support->support_id); ?>

                        <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2 || Auth::user()->role_id == 4): ?>
                            <a href="<?php echo e(route('support.edit', $support->support_id)); ?>" style="float: left; margin-left: 2px;">
                                <i class="fa fa-edit" style="font-size: 12px; color: #007bff"></i>
                            </a>
                        <?php endif; ?>
                        <i class="fa fa-upload" style="font-size: 12px; color: #007bff; float: left;"></i>
                        <a href="support/<?php echo e($support->support_id); ?>" title="show support" style="float: left; margin-left: 2px;"> <i class="fa fa-download" style="font-size: 12px; color: #007bff"></i> </a>




                        <div class="clicker" tabindex="1" style="float: left; margin-left: 2px;"><i class="fa fa-key" style="font-size: 12px; color: #007bff" title="show access data"></i></div>
                        <div class="hiddendiv"><div class="sub"><?php echo $support->access_data; ?></div></div>



                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>

<!--
<div id="myModal" class="modal">
    <?php $__currentLoopData = $task_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal-content">
        <span class="close">&times;</span>

        <p><?php echo $task->access_data; ?></p>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
-->








<script>

/*
    // Add active class to the current button (highlight it)
    var header = document.getElementById("tasksNote");
    var btns = header.getElementsByClassName("taskNotesBtn");
    for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function() {
            var current = document.getElementsByClassName("taskNotesDetails")[0];
            current[0].className = current[0].className.replace(" active", "");
            this.className += " active";


            var x = document.getElementsByClassName("active")[0];
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        });
    }

    //open and close task's details
    //function myFunction() {

    //}
*/

/*
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal
    btn.onclick = function() {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    */
</script>



<?php $__env->stopSection(); ?>


<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'layouts.appadmin' : 'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>