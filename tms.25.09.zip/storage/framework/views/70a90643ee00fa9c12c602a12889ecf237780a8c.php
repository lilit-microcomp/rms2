<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card card-default">
                    <div class="card-header">Edit account!</div>

                    <div class="card-body">
                        <?php echo Form::model($user, ['method' => 'PATCH', 'route' => ['users.update_account', $user->id]]); ?>



                        <div class="row">
                            <div class="col-md-12">
                                <!--<div class="form-group row">
                                    <label for="old_password" class="col-md-4 col-form-label text-md-right">Old Password</label>

                                    <div class="col-md-6">
                                        <?php echo Form::text('old_password', null, $attributes = $errors->has('old_password') ? array('placeholder' => 'Old Password', 'class' => 'form-control is-invalid') : array('placeholder' => 'Old Password', 'class' => 'form-control')); ?>

                                        <?php if($errors->has('old_password')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('old_password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>-->


                                <div class="form-group row">
                                    <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                                    <div class="col-md-6">
                                    <!-- <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required> -->
                                        <?php echo Form::password('password', $attributes = $errors->has('password') ? array('placeholder' => 'Password', 'class' => 'form-control is-invalid') : array('placeholder' => 'Password', 'class' => 'form-control', 'required')); ?>

                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Confirm Password</label>

                                    <div class="col-md-6">
                                        <!-- <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required> -->
                                        <?php echo Form::password('password_confirmation', ['class' => 'form-control', 'id' => 'password-confirm', 'placeholder' => 'Confirm Password', 'required']); ?>

                                    </div>
                                </div>

                            </div>


                            <div class="form-group row mb-0">
                                <div class="col-md-12 offset-md-6">
                                    <a class="btn btn-xs btn-success" href="<?php echo e(route('users.index')); ?>">Back</a>
                                    <button type="submit" class="btn btn-xs btn-primary" name="button">Submit</button>
                                </div>
                            </div>

                        </div>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'layouts.appadmin' : 'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>