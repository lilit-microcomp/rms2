

<ul class="comment odd alt">
    <div class="comment-body" >
    <div style="margin-top: 5px;">

        <div> <!-- left border style="border-left: 1px solid #CFCFCF;" -->
            <p style="font-size: 14px"><?php echo e($comment->user_name); ?> &nbsp;<?php echo e($comment->created_at); ?> &nbsp;&nbsp;</p>
            <p style="font-size: 14px"><?php echo $comment->text; ?></p>
        </div>

    </div>

    <!--<div class="comment-author vcard">
			<cite class="fn"><?php echo e($comment->user_name); ?></cite>
        </div>
        <div class="comment-meta commentmetadata">
			<p><?php echo e($comment->text); ?></p>
        </div>-->
        <div class="reply text-right" data-comment-id = <?php echo $comment->id; ?> >
            <a rel="nofollow" href="#add_comment" class="btn btn-primary comment-reply-link show-comment-box" data-toggle="collapse" style="width: 100px;">Reply</a>
        </div>
        <?php if($comment_id): ?>
            <li>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($comment->parent_id == $comment_id): ?>
                        <?php echo $__env->make('comments.comments_block', [
                        'comment' => $comment,
                        'comment_id' => $comment->id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>
        <?php endif; ?>
    </div>
</ul>

