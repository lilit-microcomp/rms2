<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>

    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <div>

        <?php echo $__env->make('includes.headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="container">
          <?php echo $__env->yieldContent('content'); ?>

          <?php echo $__env->yieldContent('comments'); ?>
        </div>

        <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
