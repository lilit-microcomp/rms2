<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Welcome to Micro-Comp TMS</h2>
<br/>
<h4>Your login: <?php echo e($email); ?></h4>
<h4>Your password: <?php echo e($password); ?></h4>
</body>

</html>