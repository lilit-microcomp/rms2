<?php echo Form::model($support[0], ['route' => ['support.saveComment', $support[0]->support_id], 'method' => 'POST', 'disabled' => false]); ?>

<?php echo $__env->make('comments.crud.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::close(); ?>

