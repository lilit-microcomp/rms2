<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">




<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card card-default">
                <!--<div class="card-header">Show Task!<br><?php echo $supports->description; ?></div>-->


                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>
                    <div id="comment-common-box" class="card-body">
                    <!-- <?php echo e(Form::commentComponent('sss', null, array('name' => 'due_date', 'placeholder' => 'Due date', 'class' => 'form-control', 'disabled' => 'disabled' ))); ?> -->
                        <div id="add-new-comment">

                            <a class="btn btn-xs btn-success" href="<?php echo e(route('support.index')); ?>">Back</a>
                            <a class="btn btn-primary show-comment-box">Add Note</a>
                            <div class="comment-box d-none">
                                <?php echo $__env->make('comments.crud.create_supp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>

                    </div>

                </div>
                <?php if(isset($comments) && (!empty($comments))): ?>
                    <div class="comments" style="border: 1px solid black; margin-top: 20px; padding: 10px;">
                        <?php echo $__env->make('comments.index', $comments, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-4 card card-default" style="background-color: #f8f8f8">

                <?php if($support[0]->status == 0): ?>
                    <span style="font-size: 14px;"><b>Status:</b>&nbsp;&nbsp;<i class="fa fa-circle" style="color: #28a745;"></i></span>
                <?php else: ?>
                    <span style="font-size: 14px;"><b>Status:</b>&nbsp;&nbsp;<i class="fa fa-circle" style="color: #007bff;"></i></span>
                <?php endif; ?>
                <b style="margin-top: 15px;">Task Description:</b>
                <p style="margin-top: 15px;"><?php echo e(isset($support) && !empty($support[0])?  $support[0]->description : ""); ?></p>
                <hr>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'layouts.appadmin' : 'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>