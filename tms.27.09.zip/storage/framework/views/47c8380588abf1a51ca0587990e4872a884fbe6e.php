<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card card-default">
                <div class="card-header">Edit support!</div>

                <div class="card-body">
                    <?php echo Form::model($support[0], ['method' => 'PATCH', 'route' => ['support.update', $support[0]->support_supportid], 'disabled' => true]); ?>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group row">
                                <label for="firstname" class="col-md-4 col-form-label text-md-right">Choose client</label>

                                <div class="col-md-6">
                                    <?php echo e(Form::select('client_id', $clients, null, $errors->has('client_id') ? ['disabled' => 'disabled', 'placeholder' => 'Please select ...', 'class' => 'form-control is-invalid'] : ['disabled' => 'disabled','placeholder' => 'Please select ...', 'class' => 'form-control'])); ?>

                                    <?php if($errors->has('client_id')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('client_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>



                            <div class="form-group row">
                                <label for="firstname" class="col-md-4 col-form-label text-md-right">Project URL</label>

                                <div class="col-md-6">
                                    <?php echo e(Form::text('project_url', null, $errors->has('project_url') ? ['disabled' => 'disabled', 'placeholder' => 'Project URL', 'class' => 'form-control is-invalid'] : ['disabled' => 'disabled','placeholder' => 'Project URL', 'class' => 'form-control'])); ?>

                                    <?php if($errors->has('project_url')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('project_url')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>



                            <div class="form-group row">
                                <label for="due_date" class="col-md-4 col-form-label text-md-right">Cycle Date</label>

                                <div class="col-md-6">
                                    <?php echo Form::text('due_date', "$cycle_date1", array('name' => 'due_date', 'placeholder' => 'Cycle Date', 'class' => 'form-control', 'id' => 'datepicker-end', 'disabled' => 'enable')); ?>


                                    <?php if($errors->has('due_date')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('due_date')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>



                            <div class="form-group row">
                                <label for="team_lead_id" class="col-md-4 col-form-label text-md-right">Choose team lead</label>

                                <div class="col-md-6">
                                    <?php echo e(Form::select('team_lead_id', $lead_user, null, ['placeholder' => 'Please select ...', 'class' => 'form-control'])); ?>


                                    <?php if($errors->has('team_lead_id')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('team_lead_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="developer_id" class="col-md-4 col-form-label text-md-right">Choose developer</label>

                                <div class="col-md-6">
                                    <?php echo e(Form::select('developer_id', $dev_user, null, $errors->has('developer_id') ? ['placeholder' => 'Please select ...', 'class' => 'form-control is-invalid']: ['placeholder' => 'Please select ...', 'class' => 'form-control'])); ?>


                                    <?php if($errors->has('developer_id')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('developer_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="pm_id" class="col-md-4 col-form-label text-md-right">Choose PM</label>

                                <div class="col-md-6">
                                    <?php echo e(Form::select('pm_id', $pm_user, null, $errors->has('pm_id') ? ['placeholder' => 'Please select ...', 'class' => 'form-control is-invalid']: ['placeholder' => 'Please select ...', 'class' => 'form-control'])); ?>


                                    <?php if($errors->has('pm_id')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('pm_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="send_email_notification" class="col-md-4 col-form-label text-md-right">Send e-mail notification?</label>

                                <div class="col-md-6">
                                    <div class="form-check form-check-inline">
                                        <?php echo Form::radio('send_email_notification', '1', true, array('class' => 'form-check-input', 'type' => 'radio', 'id' => 'inlineRadio2')); ?>

                                        <label class="form-check-label" for="inlineRadio2">Yes</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <?php echo Form::radio('send_email_notification', '0', array('class' => 'form-check-input', 'type' => 'radio', 'id' => 'inlineRadio')); ?>

                                        <label class="form-check-label" for="inlineRadio1">No</label>
                                    </div>
                                    <?php if($errors->has('send_email_notification')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('send_email_notification')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="description" class="col-md-4 col-form-label text-md-right">Description</label>

                                <div class="col-md-6">
                                    <?php echo Form::textarea('description', null, array('placeholder' => 'Description','size' => '30x5', 'class' => 'form-control', 'id' => 'description')); ?>

                                    <?php if($errors->has('description')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="access_data" class="col-md-4 col-form-label text-md-right">Access Data</label>

                                <div class="col-md-6">
                                    <?php echo Form::textarea('access_data', null, array('placeholder' => 'Access_data','size' => '30x5', 'class' => 'form-control', 'id' => 'access_data')); ?>

                                    <?php if($errors->has('access_data')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>
                    </div>


                    <div class="form-group row mb-0">
                        <div class="col-md-12 offset-md-6">
                            <a class="btn btn-xs btn-success" href="<?php echo e(route('support.index')); ?>">Back</a>
                            <button type="submit" class="btn btn-xs btn-primary" name="button">Submit</button>
                        </div>
                    </div>

                </div>

                <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'layouts.appadmin' : 'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>