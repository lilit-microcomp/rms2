<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card card-default">
                <div class="card-header">Create new task!</div>

                <div class="card-body">
                    <?php echo Form::open(['route' => 'tasks.store', 'method' => 'POST', 'disabled' => false]); ?>

                        <?php echo $__env->make('admin.tasks.crud.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make( (Auth::user()->role_id == 1) ? 'layouts.appadmin' : 'layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>