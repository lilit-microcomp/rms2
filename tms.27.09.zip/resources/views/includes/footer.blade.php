  <div class="footer-copyright">
    <p>Copyright © MicroComp LLC. All Rights Reserved.</p>
  </div>
